import React from "react";
import { X, Trash2, ShoppingBag } from "lucide-react";
import { useStore } from "../context/StoreContext";
import { motion, AnimatePresence } from "motion/react";
import { useAuth } from "../context/AuthContext";
import axios from "axios";
import { format } from "date-fns";

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartSidebar({ isOpen, onClose }: CartSidebarProps) {
  const { cart, removeFromCart } = useStore();
  const [products, setProducts] = React.useState<any[]>([]);

  React.useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get("/api/listings");
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    fetchProducts();
  }, []);

  const cartItems = cart.map((item) => {
    const product = products.find((p) => p.id === item.productId);
    return { ...item, product };
  });

  const total = cart.reduce((sum, item) => sum + item.total, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-[#fcfbf8] shadow-2xl z-[70] flex flex-col p-8"
          >
            <div className="flex justify-between items-center mb-10">
              <h2 className="font-serif text-2xl">My Bag</h2>
              <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto -mx-8 px-8 flex flex-col gap-6">
              {cartItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-[#7a7a7a]">
                  <ShoppingBag className="w-12 h-12 mb-4 opacity-20" />
                  <p className="text-sm font-medium">Your bag is empty</p>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div key={item.productId} className="flex gap-4 border-b thin-border pb-6">
                    <div className="w-24 h-32 bg-gray-100 overflow-hidden flex-shrink-0">
                      {item.product && (
                        <img
                          src={item.product.image}
                          alt={item.product.title}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      )}
                    </div>
                    <div className="flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-1">
                        <h3 className="font-serif text-lg leading-tight">{item.product?.title || "Product"}</h3>
                        <button
                          onClick={() => removeFromCart(item.productId)}
                          className="p-1 text-[#7a7a7a] hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-[10px] uppercase tracking-widest text-[#7a7a7a] mb-2">{item.product?.brand}</p>
                      <div className="text-[10px] text-[#7a7a7a] space-y-0.5">
                        <p>From: {format(new Date(item.from), "MMM d, yyyy")}</p>
                        <p>To: {format(new Date(item.to), "MMM d, yyyy")}</p>
                      </div>
                      <div className="mt-auto pt-4 flex justify-between items-end">
                        <span className="text-sm font-medium">₹{item.total}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cartItems.length > 0 && (
              <div className="mt-8 pt-8 border-t thin-border">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-[10px] uppercase tracking-[0.2em] font-bold">Total</span>
                  <span className="text-2xl font-serif">₹{total}.00</span>
                </div>
                <button
                  onClick={() => alert("Payment logic would be integrated here.")}
                  className="w-full bg-[#2a3d32] text-white py-5 text-[10px] uppercase tracking-[0.3em] font-bold hover:bg-[#1f2d25] transition-colors"
                >
                  Pay & Reserve Now
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
