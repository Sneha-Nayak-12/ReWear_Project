import { useAuth } from "../context/AuthContext";
import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import { useStore } from "../context/StoreContext";
import { Heart, ShoppingBag } from "lucide-react";

export default function Dashboard() {
  const { user, token, logout } = useAuth();
  const navigate = useNavigate();
  const { wishlist, cart } = useStore();

  const [stats, setStats] = useState<any>(null);
  const [allProducts, setAllProducts] = useState<any[]>([]);

  useEffect(() => {
    if (!user) {
      navigate("/sign-in");
      return;
    }

    axios.get("/api/listings").then((res) => setAllProducts(res.data));

    if (token) {
      axios
        .get("/api/user/dashboard", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then((res) => setStats(res.data));
    }
  }, [user, token, navigate]);

  const wishlistItems = allProducts.filter((p) => wishlist.includes(p.id));
  const reservedItems = allProducts.filter((p) => cart.some((c) => c.productId === p.id));

  if (!user || !stats) return null;

  return (
    <div className="bg-[#fcfbf8] border-t thin-border min-h-[calc(100vh-80px)]">
      <div className="max-w-[1200px] mx-auto px-6 py-20">
        <div className="flex justify-between items-center mb-12">
          <div>
            <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-4">
              Control Room
            </div>
            <h1 className="text-4xl md:text-5xl font-serif text-[#2c2c2c]">
              Hello, {user.name}
            </h1>
          </div>
          <div className="flex gap-4">
            <Link
              to="/list-piece"
              className="bg-[#2a3d32] text-white px-6 py-3 text-[10px] uppercase tracking-[0.2em] font-semibold hover:bg-[#1f2d25] transition-colors rounded-[2px]"
            >
              New Listing
            </Link>
            <button
              onClick={logout}
              className="border thin-border px-6 py-3 text-[10px] uppercase tracking-[0.2em] font-semibold hover:bg-black/5 transition-colors rounded-[2px] text-[#2c2c2c]"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 border thin-border mb-16">
          <div className="p-8 border-b md:border-b-0 md:border-r thin-border">
            <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-4">
              Total Earnings
            </div>
            <div className="text-4xl font-serif text-[#2a3d32] mb-1">
              ₹{stats.earnings.toFixed(2)}
            </div>
          </div>
          <div className="p-8 border-b md:border-b-0 md:border-r thin-border">
            <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-4">
              Listings
            </div>
            <div className="text-4xl font-serif text-[#2c2c2c] mb-2">
              {stats.listings.length}
            </div>
            <div className="text-[9px] uppercase tracking-[0.2em] text-[#7a7a7a]">
              {stats.listings.length} Active
            </div>
          </div>
          <div className="p-8 border-b md:border-b-0 md:border-r thin-border flex flex-col justify-between">
            <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-4">
              Wishlist
            </div>
            <div className="text-4xl font-serif text-[#2c2c2c] flex items-center gap-3">
              <Heart className="w-6 h-6 text-red-500 fill-current" />
              {wishlist.length}
            </div>
          </div>
          <div className="p-8 flex flex-col justify-between">
            <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-4">
              Reservations
            </div>
            <div className="text-4xl font-serif text-[#2c2c2c] flex items-center gap-3">
              <ShoppingBag className="w-6 h-6 text-[#2a3d32]" />
              {cart.length}
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-16 mb-24">
          {/* Wishlist */}
          <div>
            <h2 className="text-2xl font-serif mb-8 flex items-center gap-3">
              Saved Pieces <span className="text-xs font-sans text-[#7a7a7a] font-normal uppercase tracking-widest bg-gray-100 px-3 py-1 rounded-full">{wishlist.length}</span>
            </h2>
            {wishlistItems.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {wishlistItems.map((item) => (
                  <Link key={item.id} to={`/product/${item.id}`} className="group block border thin-border overflow-hidden">
                    <div className="aspect-[3/4] overflow-hidden">
                      <img src={item.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={item.title} />
                    </div>
                    <div className="p-4">
                      <p className="text-[9px] uppercase tracking-widest text-[#7a7a7a]">{item.brand}</p>
                      <p className="text-xs font-serif truncate">{item.title}</p>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-[#7a7a7a] italic text-sm py-12 border thin-border text-center bg-white/40">Your wishlist is empty.</p>
            )}
          </div>

          {/* Reservations */}
          <div>
            <h2 className="text-2xl font-serif mb-8 flex items-center gap-3">
              Current Reservations <span className="text-xs font-sans text-[#7a7a7a] font-normal uppercase tracking-widest bg-gray-100 px-3 py-1 rounded-full">{cart.length}</span>
            </h2>
            {reservedItems.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {reservedItems.map((item) => (
                  <Link key={item.id} to={`/product/${item.id}`} className="group block border thin-border overflow-hidden">
                    <div className="aspect-[3/4] overflow-hidden">
                      <img src={item.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt={item.title} />
                    </div>
                    <div className="p-4">
                      <p className="text-[9px] uppercase tracking-widest text-[#7a7a7a]">{item.brand}</p>
                      <p className="text-xs font-serif truncate">{item.title}</p>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-[#7a7a7a] italic text-sm py-12 border thin-border text-center bg-white/40">You have no active reservations.</p>
            )}
          </div>
        </div>

        {/* Closet */}
        <div>
          <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-6">
            Your Listed Items
          </div>

          {stats.listings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.listings.map((item: any) => (
                <Link
                  to={`/product/${item.id}`}
                  key={item.id}
                  className="group block border thin-border relative"
                >
                  <div className="aspect-[3/4] bg-[#e6e4dc] overflow-hidden">
                    <img
                      src={item.image}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                      alt={item.title}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="p-4 bg-white/50 backdrop-blur-sm absolute bottom-0 inset-x-0 border-t thin-border">
                    <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-1">
                      {item.brand}
                    </div>
                    <div className="text-sm font-serif text-[#2c2c2c]">
                      {item.title}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="border thin-border min-h-[300px] flex flex-col items-center justify-center p-12 text-center bg-white/40">
              <h3 className="text-2xl font-serif text-[#2c2c2c] mb-6">
                No pieces listed yet.
              </h3>
              <Link
                to="/list"
                className="bg-[#2a3d32] text-white px-6 py-3 text-[10px] uppercase tracking-[0.2em] font-semibold hover:bg-[#1f2d25] transition-colors rounded-[2px]"
              >
                List your first piece
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
