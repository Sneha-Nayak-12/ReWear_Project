import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import axios from "axios";
import { useStore } from "../context/StoreContext";
import { useToast } from "../context/ToastContext";

interface Listing {
  id: number;
  title: string;
  brand: string;
  rentalPrice: number;
  buyPrice: number;
  image: string;
  category: string;
  occasion: string;
  size: string;
}

const OCCASIONS = ["All Special Occasions", "Wedding", "Formal", "Party"];

export default function SpecialOccasions() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [filtered, setFiltered] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [activeOccasion, setActiveOccasion] = useState("All Special Occasions");
  const { toggleWishlist, isInWishlist } = useStore();
  const { addToast } = useToast();

  useEffect(() => {
    // Scroll to top
    window.scrollTo(0, 0);
    axios.get("/api/listings").then((res) => {
        // Filter out "Casual" to keep it strictly special occasions
        // We'll trust our OCCASIONS array for what is "special"
        const specialListings = res.data.filter((item: Listing) => ['Wedding', 'Formal', 'Party'].includes(item.occasion));
        setListings(specialListings);
        setFiltered(specialListings);
        setLoading(false);
    }).catch(err => {
        console.error(err);
        setLoading(false);
    });
  }, []);

  useEffect(() => {
    let result = listings;
    if (activeOccasion !== "All Special Occasions") {
        result = result.filter(item => item.occasion === activeOccasion);
    }
    setFiltered(result);
  }, [activeOccasion, listings]);

  if (loading) {
    return <div className="min-h-[60vh] flex items-center justify-center pt-32 px-6 lg:px-10 max-w-[1600px] mx-auto text-center font-serif text-2xl animate-pulse">Curating pieces...</div>;
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-[40vh] md:h-[50vh] bg-[#2a3d32] overflow-hidden flex items-center justify-center">
         <img 
            src="https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&q=80&w=2670"
            alt="Special Occasions"
            className="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-overlay"
            referrerPolicy="no-referrer"
         />
         <div className="relative z-10 text-center px-6 mt-16 md:mt-0">
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-white mb-4 tracking-tight">Curated for the Moment</h1>
            <p className="text-white/80 max-w-lg mx-auto text-sm md:text-base leading-relaxed">
               Discover pieces for weddings, formals, and every unforgettable event.
            </p>
         </div>
      </div>

      <div className="max-w-[1600px] mx-auto px-6 lg:px-10 py-12 md:py-20">
         {/* Filter Tabs */}
         <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
            {OCCASIONS.map(occ => (
                <button
                   key={occ}
                   onClick={() => setActiveOccasion(occ)}
                   className={`px-6 py-3 text-[10px] uppercase tracking-[0.2em] font-semibold transition-colors rounded-[2px] ${
                       activeOccasion === occ ? 'bg-[#2a3d32] text-white' : 'bg-gray-100 text-[#7a7a7a] hover:bg-gray-200 hover:text-[#2c2c2c]'
                   }`}
                >
                   {occ}
                </button>
            ))}
         </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-12">
            {filtered.map((item) => (
              <div key={item.id} className="group relative">
                <Link
                  to={`/product/${item.id}`}
                  className="block"
                >
                  <div className="aspect-[3/4] bg-[#e6e4dc] mb-4 overflow-hidden relative">
                    <img
                      src={item.image}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                      alt={item.title}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[9px] uppercase tracking-[0.2em] font-semibold text-[#7a7a7a] mb-1">
                        {item.brand} • {item.occasion}
                      </div>
                      <div className="text-sm font-serif text-[#2c2c2c]">
                        {item.title}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm">
                        <span className="font-semibold text-[#2c2c2c]">
                          ₹{item.rentalPrice}
                        </span>
                        <span className="text-xs text-[#7a7a7a]"> /day</span>
                      </div>
                      <div className="text-[9px] text-[#7a7a7a] mt-0.5">
                        Buy ₹{item.buyPrice}
                      </div>
                    </div>
                  </div>
                </Link>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const isCurrentlyIn = isInWishlist(item.id);
                    toggleWishlist(item.id);
                    addToast(isCurrentlyIn ? "Removed from wishlist" : "Added to wishlist");
                  }}
                  className={`absolute top-4 right-4 p-2.5 rounded-full backdrop-blur-md transition-all duration-300 ${
                    isInWishlist(item.id)
                      ? "bg-red-500 text-white opacity-100"
                      : "bg-white/80 text-[#7a7a7a] opacity-0 group-hover:opacity-100 hover:text-red-500"
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${isInWishlist(item.id) ? "fill-current" : ""}`} />
                </button>
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="col-span-full text-center py-20 text-[#7a7a7a]">
                <p className="text-lg">No pieces found for {activeOccasion.toLowerCase()}.</p>
                <button 
                   onClick={() => setActiveOccasion("All Special Occasions")}
                   className="mt-6 text-[#2a3d32] bg-gray-100 px-6 py-3 rounded-[2px] hover:bg-gray-200 transition-colors uppercase tracking-widest text-[10px] font-bold"
                >
                   Clear filters
                </button>
              </div>
            )}
          </div>
      </div>
    </div>
  );
}
