import React, { createContext, useContext, useState, useEffect } from "react";

interface CartItem {
  productId: number;
  from: string;
  to: string;
  total: number;
  address: string;
}

interface StoreContextType {
  wishlist: number[];
  cart: CartItem[];
  toggleWishlist: (productId: number) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: number) => void;
  isInWishlist: (productId: number) => boolean;
  isInCart: (productId: number) => boolean;
  clearCart: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);

  // Load from local storage
  useEffect(() => {
    const savedWishlist = localStorage.getItem("wishlist");
    const savedCart = localStorage.getItem("cart");
    if (savedWishlist) setWishlist(JSON.parse(savedWishlist));
    if (savedCart) setCart(JSON.parse(savedCart));
  }, []);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem("wishlist", JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const toggleWishlist = (productId: number) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const addToCart = (item: CartItem) => {
    setCart((prev) => {
      // If already in cart, update it or keep it? User said "toggle"
      const exists = prev.find((i) => i.productId === item.productId);
      if (exists) {
        return prev.filter((i) => i.productId !== item.productId);
      }
      return [...prev, item];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.productId !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const isInWishlist = (productId: number) => wishlist.includes(productId);
  const isInCart = (productId: number) => cart.some((item) => item.productId === productId);

  return (
    <StoreContext.Provider
      value={{
        wishlist,
        cart,
        toggleWishlist,
        addToCart,
        removeFromCart,
        isInWishlist,
        isInCart,
        clearCart,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error("useStore must be used within a StoreProvider");
  }
  return context;
}
